from django.shortcuts import render
from django.http import HttpResponse 
def index(request):
    #content = "<html><body><h1>This is the day that the Lord has made, we will rejoice and be glad in it!<h4>Nothing that has been fabricated against us whether in physical or spiritual realm will work against us!</h4></h1></body></html>"
    #return HttpResponse(content) 
    path = request.path
    scheme = request.scheme
    method = request.method
    address = request.META['REMOTE_ADDR']
    user_agent = request.META['HTTP_USER_AGENT']
    path_info = request.path_info
    
    
    
    msg = f"""
        <br>Path: {path}
        <br>Address: {address}
        <br>Scheme: {scheme}
        <br>Method: {method}
        <br>User agent: {user_agent}
        
    """
    
    response = HttpResponse("This works")
    return response(msg, content_type="text/html",charset="utf-8")

